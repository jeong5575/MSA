from flask import Flask # import flask module
from flask import render_template
from flask import Flask, render_template, request, redirect, url_for, session
import pymysql # 모듈 import
import mariadb

app = Flask(__name__) # 초기화

app = Flask(__name__)
app.secret_key = 'secret_key'


@app.route('/') # 요청 주소
def hello_world(): # 함수
	name = '클라우드'
	return render_template(
		'index.html', use_name=name
	)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # 데이터베이스에서 사용자 정보 확인
        conn = mariadb.connect(
            user='team2',
            password='team2',   
            host='15.164.153.191',
            port=3306,
            database='team2'
        )
        cursor = conn.cursor()
        # query = f"SELECT * FROM member_table WHERE email = \'{email}\' AND password = \'{password}\'"
        query = "SELECT * FROM member WHERE email = %s AND password = %s"
        cursor.execute(query, (email, password))
        result = cursor.fetchone()

        if result is not None:
            # 로그인 성공 시 세션에 사용자 정보 저장
            session['email'] = email
            return redirect(url_for('home'))
        else:
            return "<script>alert(\'비밀번호가 일치하지않습니다.\');window.history.back();</script>"
    
    return render_template('index.html')


@app.route('/dashboard')
def dashboard():
    return  render_template('home.html')


@app.route('/home')
def home():
    return  render_template('home.html')

@app.route('/join', methods=['GET','POST']) #GET(정보보기), POST(정보수정) 메서드 허용
def join():
    if request.method == 'GET':
        return render_template("join.html")
    else:
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if not(name and email and password and confirm_password):
            return "<script>alert(\'입력되지 않은 정보가 있습니다.\');window.history.back();</script>"
        elif password != confirm_password:
            return "<script>alert(\'비밀번호가 일치하지 않습니다.\');window.history.back();</script>"
        else:
            conn = mariadb.connect(
            user='team2',
            password='team2',   
            host='15.164.153.191',
            port=3306,
            database='team2'
            )
            cursor = conn.cursor()
            confirm = "SELECT * FROM member WHERE email = %s;"
            cursor.execute(confirm,(email,))
            result = cursor.fetchone()
            if result :
                return "<script>alert(\'이미 가입된 이메일입니다.\');</script>"
            else :
                query = "INSERT INTO member(NAME, PASSWORD, email) VALUE (%s,%s,%s);"
                cursor.execute(query, (email, password,email))
                conn.commit()
                cursor.close()
                conn.close()

            return "<script>alert(\'회원가입이 완료되었습니다.\');</script>"


           


@app.route('/notice')
def getNoticeList():
    conn = mariadb.connect(
            user='team2',
            password='team2',   
            host='15.164.153.191',
            port=3306,
            database='team2'
            )
    cursor = conn.cursor()
    search = request.args.get('search')

    if search:
        query = "SELECT title, member.name, TIME FROM board JOIN member ON  member.email=board.email WHERE board_type='Notice' AND (content like concat('%%', %s, '%%') OR title like concat('%%', %s, '%%'));"
        cursor.execute(query,(search,search))
        rows = cursor.fetchall()
        return  render_template('notice.html', rows=rows)
    else: 
        query = "SELECT title, member.name, TIME FROM board JOIN member ON member.email=board.email WHERE board_type='Notice';"
        cursor.execute(query)
        rows = cursor.fetchall()
        return  render_template('notice.html', rows=rows)


@app.route('/qna')
def qna():
    return  render_template('qna.html')

@app.route('/study')
def study():
    return  render_template('study.html')

@app.route('/community')
def community():
    return  render_template('community.html')

if __name__ == '__main__':
    app.secret_key = 'your_secret_key'
    app.run(debug=True) # flask 실행