from flask import Flask # import flask module
from flask import render_template
import pymysql # 모듈 import

app = Flask(__name__) # 초기화

# 가짜 데이터베이스
users = [
    {'id': 1, 'username': 'user1', 'password': 'pass1'},
    {'id': 2, 'username': 'user2', 'password': 'pass2'},
    {'id': 3, 'username': 'user3', 'password': 'pass3'}
]


@app.route('/python') # 요청 주소
def python(): # 함수
	return {'name':'hong', 'age':30}

@app.route('/') # 요청 주소
def hello_world(): # 함수
	name = '클라우드'
	return render_template(
		'index.html', use_name=name
	)

@app.route('/emp') # 요청 주소
def emp(): # 함수
	conn = pymysql.connect(
		host='127.0.0.1', user='root', password='mariadb',
		db='cloud', charset='utf8'
	) # 데이터베이스 접속
	cursor = conn.cursor() # 커서 객체 생성
	sql = '''
		select empno, job, mgr, ename
			, hiredate, sal, comm, deptno
			, (select count(*) from emp) as cnt
		from emp
	'''
	cursor.execute(sql) # SQL 실행
	rows = cursor.fetchall()
	cursor.close() # 커서 객체 종료
	conn.close() # 접속 해제
	age = 50

	return render_template(
		'emp.html', rows=rows,
		age=age
	)


from flask import request
@app.route('/join', methods=['get','post'])
def join():
	method = request.method #요청방식 get, post
	if method == 'GET':
		return render_template('join.html')
	else:
		name = request.form.get('name')
		email = request.form.get('email')
		password = request.form.get('password')
		conformPassword = request.form.get('confirm_password')
	
	if password == conformPassword:
		#패스워드 일치
		return redirect('/index.html')
	else :
		return 'error'
		#패스워드 불일치
		

	
@app.route('/write', methods=['get','post'])
def write():
	method = request.method
	if method == 'GET':
		return render_template('write.html')
	else :
		title = request.form.get('title')
		content = request.form.get('content')
		conn = pymysql.connect(
			host='15.164.153.191', user='cloud', password='1234',
			db='cloud', charset='utf8'
		) # 데이터베이스 접속
		cursor = conn.cursor() # 커서 객체 생성
		sql = '''
			insert into BOARD(seq_no,title,content,code)
			values (%s, %s, %s, %s)
		'''
		cursor.execute(sql, (100, title, content, 'a')) # SQL 실행
		conn.commit()
		cursor.close() # 커서 객체 종료
		conn.close() # 접속 해제
		return f'{title} / {content}'


@app.route('/login', methods=['get', 'post'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user = authenticate(username, password)
        if user:
            return redirect(url_for('dashboard', username=username))
        else:
            error = 'Invalid credentials. Please try again.'
            return render_template('index.html', error=error)
    return render_template('login.html')


@app.route('/dashboard/<username>')
def dashboard(username):
    return render_template('dashboard.html', username=username)

def authenticate(username, password):
    for user in users:
        if user['username'] == username and user['password'] == password:
            return user
    return None


if __name__ == '__main__':
	app.run(debug=True) # flask 실행