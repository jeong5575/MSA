from flask import Flask, render_template, request, redirect, url_for
import sqlite3
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'  # 비밀 키 설정

# 데이터베이스 초기화
def init_db():
    conn = sqlite3.connect('board.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS posts
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 title TEXT NOT NULL,
                 author TEXT NOT NULL,
                 content TEXT NOT NULL,
                 created_at TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS comments
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 post_id INTEGER NOT NULL,
                 author TEXT NOT NULL,
                 content TEXT NOT NULL,
                 created_at TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS likes
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 post_id INTEGER NOT NULL,
                 created_at TEXT NOT NULL)''')
    conn.commit()
    conn.close()

# 초기화 함수 실행
init_db()

# 메인 페이지 - 게시글 목록
@app.route('/')
def index():
    conn = sqlite3.connect('board.db')
    c = conn.cursor()
    c.execute('''SELECT posts.id, posts.title, posts.author, posts.created_at, COUNT(likes.id) AS like_count
                 FROM posts LEFT JOIN likes ON posts.id = likes.post_id
                 GROUP BY posts.id
                 ORDER BY posts.id DESC''')
    posts = c.fetchall()
    conn.close()
    return render_template('index.html', posts=posts)

# 게시글 보기
@app.route('/post/<int:post_id>', methods=['GET', 'POST'])
def view_post(post_id):
    if request.method == 'POST':
        author = request.form['author']
        content = request.form['content']
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M")  # 분 단위까지 표현
        conn = sqlite3.connect('board.db')
        c = conn.cursor()
        c.execute('''INSERT INTO comments (post_id, author, content, created_at)
                     VALUES (?, ?, ?, ?)''', (post_id, author, content, created_at))
        conn.commit()
        conn.close()
        return redirect(url_for('view_post', post_id=post_id))

    conn = sqlite3.connect('board.db')
    c = conn.cursor()
    c.execute('''SELECT posts.id, posts.title, posts.author, posts.content, posts.created_at, COUNT(likes.id) AS like_count
                 FROM posts LEFT JOIN likes ON posts.id = likes.post_id
                 WHERE posts.id = ? GROUP BY posts.id''', (post_id,))
    post = c.fetchone()
    c.execute('''SELECT * FROM comments WHERE post_id = ? ORDER BY id ASC''', (post_id,))
    comments = c.fetchall()
    conn.close()
    return render_template('post.html', post=post, comments=comments)

# 게시글 작성
@app.route('/new_post', methods=['GET', 'POST'])
def new_post():
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        content = request.form['content']
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M")  # 분 단위까지 표현
        conn = sqlite3.connect('board.db')
        c = conn.cursor()
        c.execute('''INSERT INTO posts (title, author, content, created_at)
                     VALUES (?, ?, ?, ?)''', (title, author, content, created_at))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('new_post.html')

# 게시글 추천
@app.route('/like_post/<int:post_id>', methods=['POST'])
def like_post(post_id):
    conn = sqlite3.connect('board.db')
    c = conn.cursor()
    c.execute('''INSERT INTO likes (post_id, created_at)
                 VALUES (?, ?)''', (post_id, datetime.now()))
    conn.commit()
    conn.close()
    return redirect(url_for('view_post', post_id=post_id))

# 게시글 수정
@app.route('/edit_post/<int:post_id>', methods=['GET', 'POST'])
def edit_post(post_id):
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        conn = sqlite3.connect('board.db')
        c = conn.cursor()
        c.execute("UPDATE posts SET title = ?, content = ? WHERE id = ?", (title, content, post_id))
        conn.commit()
        conn.close()
        return redirect(url_for('view_post', post_id=post_id))

    conn = sqlite3.connect('board.db')
    c = conn.cursor()
    c.execute("SELECT * FROM posts WHERE id = ?", (post_id,))
    post = c.fetchone()
    conn.close()
    return render_template('edit_post.html', post=post)

# 게시글 삭제
@app.route('/delete_post/<int:post_id>', methods=['POST'])
def delete_post(post_id):
    conn = sqlite3.connect('board.db')
    c = conn.cursor()
    c.execute("DELETE FROM posts WHERE id = ?", (post_id,))
    c.execute("DELETE FROM comments WHERE post_id = ?", (post_id,))
    c.execute("DELETE FROM likes WHERE post_id = ?", (post_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

# 댓글 삭제
@app.route('/delete_comment/<int:comment_id>', methods=['POST'])
def delete_comment(comment_id):
    conn = sqlite3.connect('board.db')
    c = conn.cursor()
    c.execute("DELETE FROM comments WHERE id = ?", (comment_id,))
    conn.commit()
    conn.close()
    return redirect(request.referrer)

#게시글 검색
@app.route('/search')
def search():
    query = request.args.get('query')

    conn = sqlite3.connect('board.db')
    c = conn.cursor()
    c.execute("SELECT * FROM posts WHERE title LIKE ?", ('%' + query + '%',))
    results = c.fetchall()
    conn.close()

    return render_template('search.html', query=query, results=results)

if __name__ == '__main__':
    app.run(debug=True)