from flask import Flask, render_template, request, redirect, url_for, session
import pymysql
import mariadb
from datetime import datetime

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'  # 비밀 키 설정



@app.route('/') # 요청 주소
def hello_world(): # 함수
	name = '클라우드'
	return render_template(
		'index.html', use_name=name
	)

#회원가입
@app.route('/join', methods=['GET','POST']) #GET(정보보기), POST(정보수정) 메서드 허용
def join():
    if request.method == 'GET':
        return render_template("join.html")
    else:
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if not(name and email and password and confirm_password):
            return "<script>alert(\'입력되지 않은 정보가 있습니다.\');window.history.back();</script>"
        elif password != confirm_password:
            return "<script>alert(\'비밀번호가 일치하지 않습니다.\');window.history.back();</script>"
        else:
            conn = mariadb.connect(
            user='team2',
            password='team2',   
            host='15.164.153.191',
            port=3306,
            database='team2'
            )
            cursor = conn.cursor()
            confirm = "SELECT * FROM member WHERE email = %s;"
            cursor.execute(confirm,(email,))
            result = cursor.fetchone()
            if result :
                return "<script>alert(\'이미 가입된 이메일입니다.\');</script>"
            else :
                query = "INSERT INTO member(NAME, PASSWORD, email) VALUE (%s,%s,%s);"
                cursor.execute(query, (email, password,email))
                conn.commit()
                cursor.close()
                conn.close()
            redirect('index.html')
            return "<script>alert(\'회원가입이 완료되었습니다.\');</script>"
              
#로그인
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # 데이터베이스에서 사용자 정보 확인
        conn = mariadb.connect(
            user='team2',
            password='team2',   
            host='15.164.153.191',
            port=3306,
            database='team2'
        )
        cursor = conn.cursor()
        # query = f"SELECT * FROM member_table WHERE email = \'{email}\' AND password = \'{password}\'"
        query = "SELECT * FROM member WHERE email = %s AND password = %s"
        cursor.execute(query, (email, password))
        result = cursor.fetchone()

        if result is not None:
            # 로그인 성공 시 세션에 사용자 정보 저장
            session['email'] = email
            return redirect(url_for('home'))
        else:
            return "<script>alert(\'비밀번호가 일치하지않습니다.\');window.history.back();</script>"
    
    return render_template('index.html')

@app.route('/dashboard')
def dashboard():
    return render_template('home.html')

# 데이터베이스 설정
conn = pymysql.connect(
    host='15.164.153.191',
    port=3306,
    user='team2',
    password='team2',
    database='team2'
)
cursor = conn.cursor()
# 'comments' 테이블 생성
cursor.execute('''
    CREATE TABLE IF NOT EXISTS comments (
        C_numb INT AUTO_INCREMENT PRIMARY KEY,
        answer TEXT NOT NULL,
        time DATETIME NOT NULL,
        B_numb INT NOT NULL,
        email VARCHAR(255) NOT NULL,
        FOREIGN KEY (B_numb) REFERENCES board(B_numb),
        FOREIGN KEY (email) REFERENCES member(email)
    );
''')
conn.commit()
cursor.close()
conn.close()

@app.route('/home')
def home():
    return  render_template('home.html')

# 메인 페이지 - 게시글 목록
@app.route('/community')
def index():
    conn = pymysql.connect(
        host='15.164.153.191',
        port=3306,
        user='team2',
        password='team2',
        database='team2'
    )
    cursor = conn.cursor()
    cursor.execute('''SELECT B_numb, title, email, time
                     FROM board
                     ORDER BY B_numb DESC''')
    posts = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('community.html', posts=posts)


# 게시글 보기와 댓글 작성
@app.route('/post/<int:post_id>', methods=['GET', 'POST'])
def view_post(post_id):
    if request.method == 'POST':
        content = request.form['content']
        email = session['email']  # 현재 로그인한 사용자의 이메일

        conn = mariadb.connect(
            user='team2',
            password='team2',   
            host='15.164.153.191',
            port=3306,
            database='team2'
        )
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO comments (answer, time, B_numb, email)
            VALUES (%s, %s, %s, %s)
        ''', (content, datetime.now(), post_id, email))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('view_post', post_id=post_id))

    conn = mariadb.connect(
        user='team2',
        password='team2',   
        host='15.164.153.191',
        port=3306,
        database='team2'
    )
    cursor = conn.cursor()
    cursor.execute('''SELECT B_numb, title, email, content, time
                     FROM board
                     WHERE B_numb = %s''', (post_id,))
    post = cursor.fetchone()
    cursor.execute('''SELECT * FROM comments WHERE B_numb = %s ORDER BY C_numb ASC''', (post_id,))
    comments = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('post.html', post=post, comments=comments)

@app.route('/new_post', methods=['GET', 'POST'])
def new_post():
    if request.method == 'POST':
        title = request.form['title']
        author = session['email']  # 현재 로그인한 사용자의 이메일을 사용합니다.
        content = request.form['content']
        created_at = datetime.now().strftime("%Y-%m-%d %H:%M")
        conn = pymysql.connect(
            host='15.164.153.191',
            port=3306,
            user='team2',
            password='team2',
            database='team2'
        )
        cursor = conn.cursor()
        cursor.execute('''INSERT INTO board (title, email, content, time, board_type)
                         VALUES (%s, %s, %s, %s, %s)''', (title, author, content, created_at, 'free'))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('index'))
    return render_template('new_post.html')

#검색
@app.route('/search')
def search():
    query = request.args.get('query')

    conn = pymysql.connect(
        user='team2',
        password='team2',
        host='15.164.153.191',
        port=3306,
        database='team2'
    )
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM board WHERE title LIKE %s", ('%' + query + '%',))
    results = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('search_results.html', results=results)

# 게시글 수정
@app.route('/edit_post/<int:post_id>', methods=['GET', 'POST'])
def edit_post(post_id):
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        conn = mariadb.connect(
            user='team2',
            password='team2',   
            host='15.164.153.191',
            port=3306,
            database='team2'
        )
        cursor = conn.cursor()
        cursor.execute("UPDATE board SET title = %s, content = %s WHERE B_numb = %s", (title, content, post_id))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('view_post', post_id=post_id))

    conn = mariadb.connect(
        user='team2',
        password='team2',   
        host='15.164.153.191',
        port=3306,
        database='team2'
    )
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM board WHERE B_numb = %s", (post_id,))
    post = cursor.fetchone()
    conn.close()
    return render_template('edit_post.html', post=post)

# 게시글 삭제
@app.route('/delete_post/<int:post_id>', methods=['POST'])
def delete_post(post_id):
    conn = mariadb.connect(
        user='team2',
        password='team2',   
        host='15.164.153.191',
        port=3306,
        database='team2'
    )
    cursor = conn.cursor()
    cursor.execute("DELETE FROM comments WHERE B_numb = %s", (post_id,))
    cursor.execute("DELETE FROM board WHERE B_numb = %s", (post_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(url_for('index'))

# 댓글 삭제
@app.route('/delete_comment/<int:comment_id>', methods=['POST'])
def delete_comment(comment_id):
    conn = mariadb.connect(
        user='team2',
        password='team2',   
        host='15.164.153.191',
        port=3306,
        database='team2'
    )
    cursor = conn.cursor()
    cursor.execute("DELETE FROM comments WHERE C_numb = %s", (comment_id,))
    conn.commit()
    cursor.close()
    conn.close()
    return redirect(request.referrer)

if __name__ == '__main__':
    app.run(debug=True)